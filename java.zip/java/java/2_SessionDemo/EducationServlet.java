package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/EducationServlet")
public class EducationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        session.setAttribute("degree", request.getParameter("degree"));
        session.setAttribute("university", request.getParameter("university"));

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("Name: " + session.getAttribute("name") + "<br>");
        out.println("Age: " + session.getAttribute("age") + "<br>");
        out.println("Email: " + session.getAttribute("email") + "<br>");
        out.println("Phone: " + session.getAttribute("phone") + "<br>");
        out.println("Degree: " + session.getAttribute("degree") + "<br>");
        out.println("University: " + session.getAttribute("university"));
    }
}
