<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head><title>Education Information</title></head>
<body>

<%
    String degree = request.getParameter("degree");
    String university = request.getParameter("university");

    if (degree == null || university == null) {
%>

    <h2>Enter Education Details</h2>
    <form action="" method="post">
        Degree: <input type="text" name="degree"><br><br>
        University: <input type="text" name="university"><br><br>
        <input type="submit" value="Submit">
    </form>

<%
    } else {
%>

    <h2>Education Details Received</h2>
    <p><b>Degree:</b> <%= degree %></p>
    <p><b>University:</b> <%= university %></p>
    <a href="education.jsp">Go Back</a>

<%
    }
%>

</body>
</html>
